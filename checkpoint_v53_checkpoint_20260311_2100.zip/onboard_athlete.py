#!/usr/bin/env python3
"""
onboard_athlete.py — Generate all files needed for a new athlete.

Usage:
    python onboard_athlete.py                          # Interactive mode
    python onboard_athlete.py --config new_athlete.json # From JSON file
    python onboard_athlete.py --scan-fits path/to/fits  # Scan FIT files for HR/race hints

Generates:
    athletes/<FolderName>/athlete.yml          — athlete configuration
    athletes/<FolderName>/activity_overrides.xlsx — empty override file (with races if scanned)
    athletes/<FolderName>/athlete_data.csv     — empty athlete data file
    .github/workflows/<slug>_pipeline.yml      — GitHub Actions workflow

Also prints:
    - Dropbox folder setup commands
    - GitHub secrets to configure
    - First-run instructions
"""

import argparse
import json
import os
import re
import sys
import textwrap
from datetime import datetime, date
from pathlib import Path

# ─── Optional imports for FIT scanning ────────────────────────────────────
try:
    from fitparse import FitFile
    HAS_FITPARSE = True
except ImportError:
    HAS_FITPARSE = False

try:
    import openpyxl
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False


# ═════════════════════════════════════════════════════════════════════════════
# FIT SCANNING — extract HR stats and auto-detect races
# ═════════════════════════════════════════════════════════════════════════════

def scan_fit_file(fit_path: str) -> dict | None:
    """Extract summary stats from a single FIT file. Returns None if not a run.
    Auto-detects gzip compression (Strava exports use .fit.gz or .fit that are gzipped)."""
    import gzip
    import tempfile
    
    actual_path = fit_path
    tmp_path = None
    
    try:
        # Check if file is gzip-compressed (magic bytes 1f 8b)
        with open(fit_path, 'rb') as f:
            magic = f.read(2)
        
        if magic == b'\x1f\x8b':
            # Decompress to temp file
            tmp_fd, tmp_path = tempfile.mkstemp(suffix='.fit')
            os.close(tmp_fd)
            with gzip.open(fit_path, 'rb') as gz_in:
                with open(tmp_path, 'wb') as f_out:
                    import shutil
                    shutil.copyfileobj(gz_in, f_out)
            actual_path = tmp_path
        
        fit = FitFile(actual_path)
        # Get session data
        sessions = list(fit.get_messages("session"))
        if not sessions:
            return None
        sess = sessions[0]
        
        sport = sess.get_value("sport")
        if sport is not None and str(sport).lower() not in ("running", "trail_running"):
            return None
        
        def get(field):
            try:
                return sess.get_value(field)
            except:
                return None
        
        avg_hr = get("avg_heart_rate")
        max_hr = get("max_heart_rate")
        distance = get("total_distance")  # metres
        elapsed = get("total_elapsed_time")  # seconds
        timestamp = get("start_time")  # datetime
        avg_speed = get("enhanced_avg_speed") or get("avg_speed")  # m/s
        avg_power = get("avg_power")
        total_ascent = get("total_ascent")
        
        if distance is None or elapsed is None or elapsed < 60:
            return None
        
        distance_km = distance / 1000.0
        duration_min = elapsed / 60.0
        pace_min_km = duration_min / distance_km if distance_km > 0.1 else None
        
        filename = os.path.basename(fit_path)
        
        return {
            "file": filename,
            "date": timestamp.strftime("%Y-%m-%d") if timestamp else None,
            "timestamp": timestamp,
            "distance_km": round(distance_km, 3),
            "duration_min": round(duration_min, 1),
            "pace_min_km": round(pace_min_km, 2) if pace_min_km else None,
            "avg_hr": int(avg_hr) if avg_hr else None,
            "max_hr": int(max_hr) if max_hr else None,
            "avg_power": int(avg_power) if avg_power else None,
            "total_ascent_m": round(total_ascent, 0) if total_ascent else None,
            "fit_path": fit_path,
        }
    except Exception as e:
        return None
    finally:
        if tmp_path and os.path.exists(tmp_path):
            try:
                os.remove(tmp_path)
            except:
                pass


def scan_fit_folder(folder: str, verbose: bool = True) -> list[dict]:
    """Scan all FIT files in a folder (or zip). Returns list of run summaries."""
    import zipfile
    import tempfile
    import gzip
    import shutil
    
    runs = []
    fit_files = []
    
    # Handle zip file
    if folder.endswith(".zip") and os.path.isfile(folder):
        tmpdir = tempfile.mkdtemp(prefix="fit_scan_")
        if verbose:
            print(f"Extracting {folder}...")
        with zipfile.ZipFile(folder, "r") as zf:
            members = [m for m in zf.namelist() if m.upper().endswith(".FIT") or m.upper().endswith(".FIT.GZ")]
            if verbose:
                print(f"  Found {len(members)} FIT files in zip")
            for m in members:
                zf.extract(m, tmpdir)
                extracted = os.path.join(tmpdir, m)
                if extracted.upper().endswith(".FIT.GZ"):
                    # Decompress .fit.gz → .fit
                    fit_path = extracted[:-3]  # strip .gz
                    with gzip.open(extracted, 'rb') as gz_in:
                        with open(fit_path, 'wb') as f_out:
                            shutil.copyfileobj(gz_in, f_out)
                    os.remove(extracted)
                    fit_files.append(fit_path)
                else:
                    fit_files.append(extracted)
    else:
        # Walk directory
        for root, dirs, files in os.walk(folder):
            for f in files:
                fpath = os.path.join(root, f)
                if f.upper().endswith(".FIT"):
                    fit_files.append(fpath)
                elif f.upper().endswith(".FIT.GZ"):
                    # Decompress in place
                    fit_path = fpath[:-3]
                    try:
                        with gzip.open(fpath, 'rb') as gz_in:
                            with open(fit_path, 'wb') as f_out:
                                shutil.copyfileobj(gz_in, f_out)
                        fit_files.append(fit_path)
                    except Exception:
                        pass
        if verbose:
            print(f"Found {len(fit_files)} FIT files")
    
    total = len(fit_files)
    for i, fp in enumerate(sorted(fit_files)):
        if verbose and (i + 1) % 100 == 0:
            print(f"  Scanned {i+1}/{total}...")
        result = scan_fit_file(fp)
        if result:
            runs.append(result)
    
    if verbose:
        print(f"  → {len(runs)} running activities found")
    
    runs.sort(key=lambda r: r.get("timestamp") or datetime.min)
    return runs


def estimate_hr_zones(runs: list[dict]) -> dict:
    """Estimate LTHR and max HR from run data."""
    max_hrs = [r["max_hr"] for r in runs if r.get("max_hr") and r["max_hr"] > 100]
    avg_hrs = [r["avg_hr"] for r in runs if r.get("avg_hr") and r["avg_hr"] > 80]
    
    if not max_hrs:
        return {"max_hr": None, "lthr": None, "confidence": "none", "note": "No HR data found"}
    
    # Max HR: take 95th percentile of max HR values (avoids single-spike outliers)
    if HAS_NUMPY:
        max_hr = int(np.percentile(max_hrs, 95))
    else:
        sorted_hrs = sorted(max_hrs)
        idx = int(len(sorted_hrs) * 0.95)
        max_hr = sorted_hrs[min(idx, len(sorted_hrs) - 1)]
    
    # LTHR estimation: look at runs that are likely tempo/threshold efforts
    # These are runs 20-60 min, moderate-to-hard effort (avg HR > 75% of max)
    threshold_hrs = []
    for r in runs:
        if (r.get("avg_hr") and r.get("duration_min") 
            and 20 <= r["duration_min"] <= 60
            and r["avg_hr"] > max_hr * 0.75):
            threshold_hrs.append(r["avg_hr"])
    
    if threshold_hrs:
        if HAS_NUMPY:
            lthr = int(np.percentile(threshold_hrs, 85))
        else:
            sorted_th = sorted(threshold_hrs)
            idx = int(len(sorted_th) * 0.85)
            lthr = sorted_th[min(idx, len(sorted_th) - 1)]
        confidence = "moderate" if len(threshold_hrs) > 10 else "low"
    else:
        # Fallback: 89% of max HR (Karvonen approximation)
        lthr = int(max_hr * 0.89)
        confidence = "estimated"
    
    n_with_hr = len(avg_hrs)
    n_total = len(runs)
    
    return {
        "max_hr": max_hr,
        "lthr": lthr,
        "confidence": confidence,
        "n_with_hr": n_with_hr,
        "n_total": n_total,
        "note": f"Based on {n_with_hr}/{n_total} runs with HR data. "
                f"Confidence: {confidence}. Review and adjust if needed."
    }


def detect_races(runs: list[dict]) -> list[dict]:
    """Auto-detect likely race efforts from run data."""
    if not runs:
        return []
    
    # Build pace distribution for calibration
    paces = [r["pace_min_km"] for r in runs if r.get("pace_min_km") and r["pace_min_km"] > 2.5]
    if not paces or len(paces) < 20:
        return []
    
    if HAS_NUMPY:
        pace_p10 = np.percentile(paces, 10)  # fast end
        pace_median = np.median(paces)
    else:
        sorted_paces = sorted(paces)
        pace_p10 = sorted_paces[int(len(sorted_paces) * 0.10)]
        pace_median = sorted_paces[len(sorted_paces) // 2]
    
    races = []
    
    for r in runs:
        if not r.get("pace_min_km") or not r.get("avg_hr") or not r.get("distance_km"):
            continue
        
        dist = r["distance_km"]
        pace = r["pace_min_km"]
        hr = r["avg_hr"]
        dur = r.get("duration_min", 0)
        
        # Heuristics for race detection:
        is_race = False
        race_distance = None
        race_type = None
        confidence = "low"
        
        # 1. Parkrun: ~5K distance, fast pace
        if 4.8 <= dist <= 5.5 and pace < pace_p10 * 1.08:
            is_race = True
            race_distance = 5.0
            race_type = "parkrun"
            confidence = "high" if pace < pace_p10 * 1.03 else "medium"
        
        # 2. Standard race distances at race pace
        race_distances = [
            (2.8, 3.2, 3.0, "3K"),
            (4.8, 5.5, 5.0, "5K"),
            (9.5, 10.8, 10.0, "10K"),
            (14.5, 16.5, 15.0, "15K"),
            (20.5, 22.0, 21.097, "HM"),
            (25.0, 27.5, 26.2, "26K"),  # rare
            (29.5, 31.5, 30.0, "30K"),
            (41.0, 43.5, 42.195, "Marathon"),
        ]
        
        for dmin, dmax, official, label in race_distances:
            if dmin <= dist <= dmax:
                # Must be faster than typical training pace for this duration
                # And relatively even pace (races are more consistent)
                if pace < pace_median * 0.92:
                    is_race = True
                    race_distance = official
                    race_type = label
                    confidence = "medium"
                    break
        
        # 3. HR-based confirmation: avg HR > 88% of max is likely racing
        max_hrs_list = [r2["max_hr"] for r2 in runs if r2.get("max_hr") and r2["max_hr"] > 100]
        if max_hrs_list:
            est_max = sorted(max_hrs_list)[-1]
            if hr > est_max * 0.88 and is_race:
                confidence = "high"
        
        if is_race:
            races.append({
                "file": r["file"],
                "date": r["date"],
                "distance_km": race_distance,
                "actual_distance_km": round(dist, 3),
                "duration_min": r["duration_min"],
                "pace_min_km": r["pace_min_km"],
                "avg_hr": r["avg_hr"],
                "race_type": race_type,
                "confidence": confidence,
            })
    
    return races


def detect_power_meter(runs: list[dict]) -> dict:
    """Check if athlete has a power meter."""
    with_power = [r for r in runs if r.get("avg_power") and r["avg_power"] > 50]
    n_total = len(runs)
    n_power = len(with_power)
    
    if n_power == 0:
        return {"has_power": False, "mode": "gap", "note": "No power data found → GAP mode"}
    
    pct = n_power / n_total * 100 if n_total > 0 else 0
    
    # Check if it's likely Stryd (consistent power) vs Garmin (erratic)
    powers = [r["avg_power"] for r in with_power]
    if HAS_NUMPY and len(powers) > 10:
        cv = np.std(powers) / np.mean(powers)
        if cv > 0.4:  # Very high variability = likely Garmin wrist estimate
            return {
                "has_power": True, "mode": "gap",
                "n_power": n_power, "pct": round(pct, 1),
                "note": f"Power data in {n_power}/{n_total} runs but high variability "
                        f"(CV={cv:.2f}) suggests Garmin wrist estimate → GAP mode recommended"
            }
    
    if pct > 50:
        return {
            "has_power": True, "mode": "stryd",
            "n_power": n_power, "pct": round(pct, 1),
            "note": f"Power data in {n_power}/{n_total} runs ({pct:.0f}%) → Stryd mode"
        }
    else:
        return {
            "has_power": True, "mode": "gap",
            "n_power": n_power, "pct": round(pct, 1),
            "note": f"Power data in only {n_power}/{n_total} runs ({pct:.0f}%) → GAP mode recommended"
        }


# ═════════════════════════════════════════════════════════════════════════════
# FILE GENERATION
# ═════════════════════════════════════════════════════════════════════════════

def make_folder_name(name: str) -> str:
    """Convert 'Ian Lilley' → 'IanLilley'. Legacy — see next_athlete_id()."""
    return re.sub(r"[^a-zA-Z0-9]", "", name.title().replace(" ", ""))


def next_athlete_id(base_dir: str = ".") -> str:
    """Scan athletes/ for existing A### folders/IDs and return the next one.
    
    Looks at both folder names (e.g. athletes/A005/) and athlete_id values
    in athlete.yml files to find the highest existing ID.
    """
    import glob
    max_id = 0
    athletes_dir = Path(base_dir) / "athletes"
    
    if athletes_dir.exists():
        for entry in athletes_dir.iterdir():
            if not entry.is_dir():
                continue
            # Check folder name pattern A###
            m = re.match(r'^A(\d+)$', entry.name)
            if m:
                max_id = max(max_id, int(m.group(1)))
            # Also check athlete.yml inside for athlete_id
            yml_path = entry / "athlete.yml"
            if yml_path.exists():
                try:
                    with open(yml_path) as f:
                        for line in f:
                            m2 = re.search(r'athlete_id:\s*"?A(\d+)"?', line)
                            if m2:
                                max_id = max(max_id, int(m2.group(1)))
                except Exception:
                    pass
    
    return f"A{max_id + 1:03d}"


def make_slug(name: str) -> str:
    """Convert 'Ian Lilley' → 'ian_lilley' (for workflow files, pages paths, cache keys)."""
    parts = name.strip().lower().split()
    return "_".join(parts) if parts else "athlete"


def _generate_zones_yaml(cfg: dict) -> str:
    """Generate the zones section for athlete.yml.
    
    If the user customised HR zones on the onboard page, writes them as
    explicit boundaries. Otherwise computes defaults from LTHR/max_hr
    so the YAML always has zones (pipeline and dashboard read from here).
    """
    lthr = cfg.get('lthr')
    max_hr = cfg.get('max_hr')
    
    if not lthr or lthr < 100:
        return ""  # Can't compute zones without LTHR
    
    hr_zones = cfg.get('hr_zones')
    if hr_zones and isinstance(hr_zones, dict):
        # User customised zones on the onboard page
        z12 = int(hr_zones.get('z12', round(lthr * 0.81)))
        z23 = int(hr_zones.get('z23', round(lthr * 0.90)))
        z34 = int(hr_zones.get('z34', round(lthr * 0.955)))
        z45 = int(hr_zones.get('z45', lthr))
        source = "customised on onboard page"
    else:
        # Auto-calculate from LTHR (same formula as onboard.html and generate_dashboard.py)
        z12 = round(lthr * 0.81)
        z23 = round(lthr * 0.90)
        z34 = round(lthr * 0.955)
        z45 = lthr
        source = "auto-calculated from LTHR"
    
    return f"""# HR zones ({source})
# Boundaries: [Z1/Z2, Z2/Z3, Z3/Z4, Z4/Z5]
# Z1: < {z12}, Z2: {z12}-{z23}, Z3: {z23}-{z34}, Z4: {z34}-{z45}, Z5: > {z45}
zones:
  hr_zones: [{z12}, {z23}, {z34}, {z45}]

"""


def generate_athlete_yml(cfg: dict) -> str:
    """Generate athlete.yml content."""
    
    # Planned races section
    if cfg.get("planned_races"):
        races_yaml = "\n" + "\n".join([
            f'  - name: "{r["name"]}"\n'
            f'    date: "{r["date"]}"\n'
            f'    distance_km: {r["distance_km"]}\n'
            f'    priority: {r.get("priority", "B")}\n'
            f'    surface: {r.get("surface", "road")}'
            for r in cfg["planned_races"]
        ])
    else:
        races_yaml = "[]"
    
    mode = cfg.get("power_mode", "gap")
    stryd_fallback_comment = ""
    if cfg.get("_stryd_declared") and mode == "gap":
        stryd_fallback_comment = "  # NOTE: User has Stryd but insufficient power data in export (<10 runs).\n  # Change mode to 'stryd' when you have 10+ runs with Stryd power data.\n"
    # Seed PEAK_CP from weight: 4.85 W/kg is a reasonable club runner baseline.
    # StepB will bootstrap the real value from race data and write it back.
    weight_based_seed = round(4.85 * cfg['mass_kg'])
    peak_cp = cfg.get("peak_cp_watts", weight_based_seed)
    
    # Intervals section
    intervals_section = ""
    if cfg.get("data_source") == "intervals":
        intervals_section = f"""  intervals:
    athlete_id: ""        # Set via environment variable INTERVALS_ATHLETE_ID
    api_key: ""           # Set via environment variable {{SECRET_PREFIX}}_INTERVALS_API_KEY"""
    else:
        intervals_section = """  intervals:
    athlete_id: ""
    api_key: \"\""""
    
    source = cfg.get("data_source", "fit_folder")
    
    yml = f"""# =============================================================================
# ATHLETE CONFIGURATION — {cfg['name']} ({mode.upper()} Mode)
# =============================================================================
# Generated by onboard_athlete.py on {datetime.now().strftime('%Y-%m-%d %H:%M')}

athlete:
  name: "{cfg['name']}"
  athlete_id: "{cfg.get('athlete_id', 'A000')}"
  mass_kg: {cfg['mass_kg']}
  date_of_birth: "{cfg['dob']}"
  gender: "{cfg['gender']}"
  timezone: "{cfg.get('timezone', 'Europe/London')}"

  # HR thresholds
  lthr: {cfg['lthr']}
  max_hr: {cfg['max_hr']}

  # Race HR thresholds (% of LTHR). Used by classify_races.py to identify race efforts.
  # These defaults work well for most runners. Uncomment and adjust if needed.
  # race_hr_thresholds_pct:
  #   3K: 0.98
  #   5K: 0.98
  #   10K: 0.97
  #   10M: 0.95
  #   HM: 0.94
  #   30K: 0.90
  #   Marathon: 0.88

{_generate_zones_yaml(cfg)}\
planned_races: {races_yaml}

power:
  mode: "{mode}"
{stryd_fallback_comment}
  stryd:
    peak_cp_watts: {peak_cp}
    eras: {{}}
    mass_corrections: []
    re_reference_era: "s4"

  gap:
    peak_cp_watts: {peak_cp}  # Auto-updated by StepB bootstrap
    re_constant: {cfg.get('re_constant', 0.92)}

data:
  source: "{source}"
{intervals_section}
  fit_folder:
    path: "./data/fits"
  strava_export:
    zip_path: ""

pipeline:
  rf_window_duration_s: 2400
  rf_trend_window_days: 42
  rf_trend_min_periods: 5
  ctl_time_constant: 42
  atl_time_constant: 7
  temp_baseline_c: {cfg.get('temp_baseline_c', 10.0)}
  easy_rf:
    hr_min: {max(120, int(cfg['lthr'] * 0.77))}
    hr_max: 0
"""
    return yml


def generate_workflow_yml(cfg: dict) -> str:
    """Generate GitHub Actions workflow YAML."""
    
    name = cfg["name"]
    folder = cfg["folder_name"]
    slug = cfg["slug"]
    aid = cfg.get("athlete_id", "A000")  # v53: for Master filename
    mode = cfg.get("power_mode", "gap")
    mass = cfg["mass_kg"]
    dob = cfg["dob"]
    gender = cfg["gender"]
    tz = cfg.get("timezone", "Europe/London")
    source = cfg.get("data_source", "fit_folder")
    
    secret_prefix = slug.upper()
    
    # ── Header ────────────────────────────────────────────────
    header = f"""# .github/workflows/{slug}_pipeline.yml
# Pipeline for {name} — {mode.upper()} mode{"" if source == "fit_folder" else ", intervals.icu sync"}
#
# Triggers:
#   - {"Scheduled check 8x/day (skips quickly if no new activities)" if source == "intervals" else "Manual (workflow_dispatch) with mode selection"}{"" if source == "fit_folder" else chr(10) + "#   - Manual (workflow_dispatch) with mode selection"}
#
# Secrets required:
#   DROPBOX_TOKEN / DROPBOX_REFRESH_TOKEN / DROPBOX_APP_KEY / DROPBOX_APP_SECRET"""
    
    if source == "intervals":
        header += f"""
#   {secret_prefix}_INTERVALS_API_KEY    — {name}'s intervals.icu API key
#   {secret_prefix}_INTERVALS_ATHLETE_ID — {name}'s intervals.icu athlete ID"""
    
    # ── Triggers ──────────────────────────────────────────────
    if source == "intervals":
        triggers = f"""
on:
  schedule:
    - cron: '0 9,11,13,15,17,19,21,23 * * *'
  workflow_dispatch:
    inputs:
      mode:
        description: 'Pipeline mode'
        type: choice
        options:
          - UPDATE
          - FULL
          - INITIAL
          - FROM_STEPB
          - DASHBOARD
        default: UPDATE
      sync:
        description: 'Sync from intervals.icu'
        type: boolean
        default: true"""
    else:
        triggers = """
on:
  workflow_dispatch:
    inputs:
      mode:
        description: 'Pipeline mode'
        type: choice
        options:
          - FULL
          - INITIAL
          - FROM_STEPB
          - DASHBOARD
        default: FROM_STEPB"""
    
    # ── Env block ─────────────────────────────────────────────
    env_block = f"""
    env:
      DROPBOX_TOKEN: ${{{{ secrets.DROPBOX_TOKEN }}}}
      DROPBOX_REFRESH_TOKEN: ${{{{ secrets.DROPBOX_REFRESH_TOKEN }}}}
      DROPBOX_APP_KEY: ${{{{ secrets.DROPBOX_APP_KEY }}}}
      DROPBOX_APP_SECRET: ${{{{ secrets.DROPBOX_APP_SECRET }}}}"""
    
    if source == "intervals":
        env_block += f"""
      INTERVALS_API_KEY: ${{{{ secrets.{secret_prefix}_INTERVALS_API_KEY }}}}
      INTERVALS_ATHLETE_ID: ${{{{ secrets.{secret_prefix}_INTERVALS_ATHLETE_ID }}}}"""
    
    env_block += f"""
      ATHLETE_DIR: athletes/{folder}
      ATHLETE_CONFIG_PATH: athletes/{folder}/athlete.yml
      DB_BASE: /Running and Cycling/DataPipeline/athletes/{folder}
      TZ_LOCAL: {tz}"""
    
    if source == "intervals":
        env_block += f"""
      PIPELINE_MODE: ${{{{ github.event.inputs.mode || 'UPDATE' }}}}"""
    
    # ── Common steps ──────────────────────────────────────────
    common_steps = f"""
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Setup Python
        uses: actions/setup-python@v5
        with:
          python-version: '3.12'
          cache: 'pip'

      - name: Install dependencies
        run: |
          pip install --upgrade pip
          pip install -r requirements.txt

      - name: Create directories
        run: |
          mkdir -p ${{{{ env.ATHLETE_DIR }}}}/data/FIT_downloads
          mkdir -p ${{{{ env.ATHLETE_DIR }}}}/persec_cache
          mkdir -p ${{{{ env.ATHLETE_DIR }}}}/output/dashboard"""
    
    # ── Intervals.icu sync block ──────────────────────────────
    if source == "intervals":
        sync_block = f"""
      # ═══════════════════════════════════════════════════════════
      # LIGHTWEIGHT CHECK — runs every time (~30s)
      # ═══════════════════════════════════════════════════════════

      - name: Restore sync state
        uses: actions/cache/restore@v4
        with:
          path: |
            ${{{{ env.ATHLETE_DIR }}}}/fit_sync_state.json
            ${{{{ env.ATHLETE_DIR }}}}/pending_activities.csv
          key: {slug}-sync-state-${{{{ github.run_number }}}}
          restore-keys: |
            {slug}-sync-state-

      - name: Download fits.zip for dedup
        if: ${{{{ github.event.inputs.sync != 'false' && env.PIPELINE_MODE != 'DASHBOARD' && env.PIPELINE_MODE != 'FROM_STEPB' }}}}
        run: |
          python ci/dropbox_sync.py download \\
            --dropbox-base "${{{{ env.DB_BASE }}}}" \\
            --local-prefix "${{{{ env.ATHLETE_DIR }}}}" \\
            --items data/fits.zip
        continue-on-error: true

      - name: Check for new activities
        id: fetch
        if: ${{{{ github.event.inputs.sync != 'false' && env.PIPELINE_MODE != 'DASHBOARD' && env.PIPELINE_MODE != 'FROM_STEPB' }}}}
        run: |
          python fetch_fit_files.py \\
            --fit-dir ${{{{ env.ATHLETE_DIR }}}}/data/FIT_downloads \\
            --zip ${{{{ env.ATHLETE_DIR }}}}/data/fits.zip \\
            --state-file ${{{{ env.ATHLETE_DIR }}}}/fit_sync_state.json \\
            --pending-csv ${{{{ env.ATHLETE_DIR }}}}/pending_activities.csv \\
            --refresh-names 14

          if [ -f _new_runs_added.tmp ]; then
            echo "new_runs=true" >> $GITHUB_OUTPUT
            COUNT=$(cat _new_runs_added.tmp)
            echo "  → $COUNT new run(s) detected"
          else
            echo "new_runs=false" >> $GITHUB_OUTPUT
            echo "  → No new runs"
          fi
        continue-on-error: true

      - name: Decide whether to continue
        id: gate
        run: |
          if [ "${{{{ github.event_name }}}}" = "workflow_dispatch" ]; then
            echo "continue=true" >> $GITHUB_OUTPUT
          elif [ "${{{{ steps.fetch.outputs.new_runs }}}}" = "true" ]; then
            echo "continue=true" >> $GITHUB_OUTPUT
          else
            echo "continue=false" >> $GITHUB_OUTPUT
          fi

      - name: Save sync state
        uses: actions/cache/save@v4
        if: always()
        with:
          path: |
            ${{{{ env.ATHLETE_DIR }}}}/fit_sync_state.json
            ${{{{ env.ATHLETE_DIR }}}}/pending_activities.csv
          key: {slug}-sync-state-${{{{ github.run_number }}}}"""
        gate_condition = "${{ steps.gate.outputs.continue == 'true' }}"
    else:
        sync_block = ""
        gate_condition = None  # Not used for FIT-only
    
    # ── Pipeline steps ────────────────────────────────────────
    gc = gate_condition
    
    if source == "intervals":
        pipeline_block = f"""
      # ═══════════════════════════════════════════════════════════
      # FULL PIPELINE — only if new data or manual dispatch
      # ═══════════════════════════════════════════════════════════

      - name: Restore persec cache
        if: {gc}
        uses: actions/cache/restore@v4
        with:
          path: ${{{{ env.ATHLETE_DIR }}}}/persec_cache
          key: {slug}-persec-${{{{ github.run_number }}}}
          restore-keys: |
            {slug}-persec-

      - name: Download data from Dropbox
        if: {gc}
        run: |
          python ci/dropbox_sync.py download \\
            --dropbox-base "${{{{ env.DB_BASE }}}}" \\
            --local-prefix "${{{{ env.ATHLETE_DIR }}}}" \\
            --items data/activities.csv \\
                    athlete.yml \\
                    activity_overrides.xlsx \\
                    athlete_data.csv \\
                    output/Master_{aid}_FULL.xlsx \\
                    output/Master_{aid}_FULL_post.xlsx \\
                    output/_weather_cache_openmeteo/openmeteo_cache.sqlite \\
            --cache-dir ${{{{ env.ATHLETE_DIR }}}}/persec_cache
        continue-on-error: true

      - name: Sync athlete data from intervals.icu
        if: ${{{{ {gc.strip('${{ }}')} && github.event.inputs.sync != 'false' && env.PIPELINE_MODE != 'DASHBOARD' }}}}
        run: |
          python sync_athlete_data.py \\
            --athlete-data ${{{{ env.ATHLETE_DIR }}}}/athlete_data.csv \\
            --nr-tss-oldest 2020-01-01
        continue-on-error: true

      - name: Initial data ingest (INITIAL only)
        if: ${{{{ {gc.strip('${{ }}')} && env.PIPELINE_MODE == 'INITIAL' }}}}
        run: |
          python ci/initial_data_ingest.py \\
            --athlete-dir ${{{{ env.ATHLETE_DIR }}}} \\
            --dropbox-base "${{{{ env.DB_BASE }}}}" \\
            --tz ${{{{ env.TZ_LOCAL }}}}

      - name: Rebuild from FIT files (FULL)
        if: ${{{{ {gc.strip('${{ }}')} && (env.PIPELINE_MODE == 'FULL' || env.PIPELINE_MODE == 'INITIAL') }}}}
        run: |
          python rebuild_from_fit_zip.py \\
            --fit-zip ${{{{ env.ATHLETE_DIR }}}}/data/fits.zip \\
            --template master_template.xlsx \\
            --out ${{{{ env.ATHLETE_DIR }}}}/output/Master_{aid}_FULL.xlsx \\
            --persec-cache-dir ${{{{ env.ATHLETE_DIR }}}}/persec_cache \\
            --strava ${{{{ env.ATHLETE_DIR }}}}/data/activities.csv \\
            --pending-activities ${{{{ env.ATHLETE_DIR }}}}/pending_activities.csv \\
            --override-file ${{{{ env.ATHLETE_DIR }}}}/activity_overrides.xlsx \\
            --tz ${{{{ env.TZ_LOCAL }}}} \\
            --weight {mass}

      - name: Rebuild from FIT files (UPDATE — append only)
        if: ${{{{ {gc.strip('${{ }}')} && env.PIPELINE_MODE == 'UPDATE' }}}}
        run: |
          python rebuild_from_fit_zip.py \\
            --fit-zip ${{{{ env.ATHLETE_DIR }}}}/data/fits.zip \\
            --template master_template.xlsx \\
            --out ${{{{ env.ATHLETE_DIR }}}}/output/Master_{aid}_FULL.xlsx \\
            --append-master-in ${{{{ env.ATHLETE_DIR }}}}/output/Master_{aid}_FULL.xlsx \\
            --persec-cache-dir ${{{{ env.ATHLETE_DIR }}}}/persec_cache \\
            --strava ${{{{ env.ATHLETE_DIR }}}}/data/activities.csv \\
            --pending-activities ${{{{ env.ATHLETE_DIR }}}}/pending_activities.csv \\
            --override-file ${{{{ env.ATHLETE_DIR }}}}/activity_overrides.xlsx \\
            --tz ${{{{ env.TZ_LOCAL }}}} \\
            --weight {mass} \\
          || EXIT_CODE=$?
          # Exit code 2 = "success but nothing new" — continue pipeline
          if [ "${{{{EXIT_CODE:-0}}}}" -eq 2 ]; then
            echo "No new runs — continuing to StepB"
          elif [ "${{{{EXIT_CODE:-0}}}}" -ne 0 ]; then
            exit $EXIT_CODE
          fi

      - name: Add GAP power
        if: ${{{{ {gc.strip('${{ }}')} && (env.PIPELINE_MODE == 'FULL' || env.PIPELINE_MODE == 'INITIAL' || env.PIPELINE_MODE == 'UPDATE') }}}}
        run: |
          python add_gap_power.py \\
            --master ${{{{ env.ATHLETE_DIR }}}}/output/Master_{aid}_FULL.xlsx \\
            --cache-dir ${{{{ env.ATHLETE_DIR }}}}/persec_cache \\
            --out ${{{{ env.ATHLETE_DIR }}}}/output/Master_{aid}_FULL.xlsx \\
            --mass-kg {mass} \\
            --re-constant 0.92

      - name: StepB post-processing
        if: ${{{{ {gc.strip('${{ }}')} && env.PIPELINE_MODE != 'DASHBOARD' }}}}
        run: |
          python StepB_PostProcess.py \\
            --master ${{{{ env.ATHLETE_DIR }}}}/output/Master_{aid}_FULL.xlsx \\
            --persec-cache-dir ${{{{ env.ATHLETE_DIR }}}}/persec_cache \\
            --out ${{{{ env.ATHLETE_DIR }}}}/output/Master_{aid}_FULL_post.xlsx \\
            --model-json re_model_generic.json \\
            --override-file ${{{{ env.ATHLETE_DIR }}}}/activity_overrides.xlsx \\
            --athlete-data ${{{{ env.ATHLETE_DIR }}}}/athlete_data.csv \\
            --mass-kg {mass} \\
            --tz ${{{{ env.TZ_LOCAL }}}} \\
            --runner-dob "{dob}" \\
            --runner-gender {gender} \\
            --strava ${{{{ env.ATHLETE_DIR }}}}/data/activities.csv \\
            --progress-every 50

      - name: Generate dashboard
        if: {gc}
        env:
          MASTER_FILE: ${{{{ env.ATHLETE_DIR }}}}/output/Master_{aid}_FULL_post.xlsx
          OUTPUT_FILE: ${{{{ env.ATHLETE_DIR }}}}/output/dashboard/index.html
          ATHLETE_DATA_FILE: ${{{{ env.ATHLETE_DIR }}}}/athlete_data.csv
        run: python generate_dashboard.py
        continue-on-error: true

      - name: Save persec cache
        uses: actions/cache/save@v4
        if: {gc}
        with:
          path: ${{{{ env.ATHLETE_DIR }}}}/persec_cache
          key: {slug}-persec-${{{{ github.run_number }}}}

      - name: Upload fits.zip to Dropbox (only if new FITs added)
        if: ${{{{ {gc.strip('${{ }}')} && steps.fetch.outputs.new_runs == 'true' }}}}
        run: |
          python ci/dropbox_sync.py upload \\
            --dropbox-base "${{{{ env.DB_BASE }}}}" \\
            --local-prefix "${{{{ env.ATHLETE_DIR }}}}" \\
            --items data/fits.zip
        continue-on-error: true

      - name: Upload results to Dropbox
        if: {gc}
        run: |
          python ci/dropbox_sync.py upload \\
            --dropbox-base "${{{{ env.DB_BASE }}}}" \\
            --local-prefix "${{{{ env.ATHLETE_DIR }}}}" \\
            --items activity_overrides.xlsx \\
                    athlete.yml \\
                    athlete_data.csv \\
                    fit_sync_state.json \\
                    pending_activities.csv \\
                    output/Master_{aid}_FULL.xlsx \\
                    output/Master_{aid}_FULL_post.xlsx \\
                    output/dashboard/index.html \\
                    output/_weather_cache_openmeteo/openmeteo_cache.sqlite \\
            --cache-dir ${{{{ env.ATHLETE_DIR }}}}/persec_cache"""
    else:
        # FIT-folder mode: simpler, no gating
        pipeline_block = f"""
      # ─── Restore persec cache ───────────────────────────────
      - name: Restore persec cache
        uses: actions/cache/restore@v4
        with:
          path: ${{{{ env.ATHLETE_DIR }}}}/persec_cache
          key: {slug}-persec-${{{{ github.run_number }}}}
          restore-keys: |
            {slug}-persec-

      # ─── Download data from Dropbox ─────────────────────────
      - name: Download data from Dropbox
        run: |
          python ci/dropbox_sync.py download \\
            --dropbox-base "${{{{ env.DB_BASE }}}}" \\
            --local-prefix "${{{{ env.ATHLETE_DIR }}}}" \\
            --items data/fits.zip \\
                    data/activities.csv \\
                    activity_overrides.xlsx \\
                    athlete_data.csv \\
                    output/Master_{aid}_FULL.xlsx \\
                    output/Master_{aid}_FULL_post.xlsx \\
                    output/_weather_cache_openmeteo/openmeteo_cache.sqlite \\
            --cache-dir ${{{{ env.ATHLETE_DIR }}}}/persec_cache
        continue-on-error: true

      # ─── Initial data ingest (INITIAL only) ─────────────────
      - name: Initial data ingest (INITIAL only)
        if: ${{{{ github.event.inputs.mode == 'INITIAL' }}}}
        run: |
          python ci/initial_data_ingest.py \\
            --athlete-dir ${{{{ env.ATHLETE_DIR }}}} \\
            --dropbox-base "${{{{ env.DB_BASE }}}}" \\
            --tz ${{{{ env.TZ_LOCAL }}}}

      # ─── Step 1: Rebuild from FIT files ─────────────────────
      - name: Rebuild from FIT files
        if: ${{{{ github.event.inputs.mode == 'FULL' || github.event.inputs.mode == 'INITIAL' }}}}
        run: |
          python rebuild_from_fit_zip.py \\
            --fit-zip ${{{{ env.ATHLETE_DIR }}}}/data/fits.zip \\
            --template master_template.xlsx \\
            --out ${{{{ env.ATHLETE_DIR }}}}/output/Master_{aid}_FULL.xlsx \\
            --persec-cache-dir ${{{{ env.ATHLETE_DIR }}}}/persec_cache \\
            --strava ${{{{ env.ATHLETE_DIR }}}}/data/activities.csv \\
            --override-file ${{{{ env.ATHLETE_DIR }}}}/activity_overrides.xlsx \\
            --tz ${{{{ env.TZ_LOCAL }}}} \\
            --weight {mass}

      # ─── Step 2: Add GAP simulated power ────────────────────
      - name: Add GAP power
        if: ${{{{ github.event.inputs.mode == 'FULL' || github.event.inputs.mode == 'INITIAL' }}}}
        run: |
          python add_gap_power.py \\
            --master ${{{{ env.ATHLETE_DIR }}}}/output/Master_{aid}_FULL.xlsx \\
            --cache-dir ${{{{ env.ATHLETE_DIR }}}}/persec_cache \\
            --out ${{{{ env.ATHLETE_DIR }}}}/output/Master_{aid}_FULL.xlsx \\
            --mass-kg {mass} \\
            --re-constant 0.92

      # ─── Step 3: StepB post-processing ──────────────────────
      - name: StepB post-processing
        if: ${{{{ github.event.inputs.mode != 'DASHBOARD' }}}}
        run: |
          python StepB_PostProcess.py \\
            --master ${{{{ env.ATHLETE_DIR }}}}/output/Master_{aid}_FULL.xlsx \\
            --persec-cache-dir ${{{{ env.ATHLETE_DIR }}}}/persec_cache \\
            --out ${{{{ env.ATHLETE_DIR }}}}/output/Master_{aid}_FULL_post.xlsx \\
            --model-json re_model_generic.json \\
            --override-file ${{{{ env.ATHLETE_DIR }}}}/activity_overrides.xlsx \\
            --athlete-data ${{{{ env.ATHLETE_DIR }}}}/athlete_data.csv \\
            --mass-kg {mass} \\
            --tz ${{{{ env.TZ_LOCAL }}}} \\
            --runner-dob "{dob}" \\
            --runner-gender {gender} \\
            --strava ${{{{ env.ATHLETE_DIR }}}}/data/activities.csv \\
            --progress-every 50

      # ─── Step 4: Generate dashboard ─────────────────────────
      - name: Generate dashboard
        env:
          MASTER_FILE: ${{{{ env.ATHLETE_DIR }}}}/output/Master_{aid}_FULL_post.xlsx
          OUTPUT_FILE: ${{{{ env.ATHLETE_DIR }}}}/output/dashboard/index.html
          ATHLETE_DATA_FILE: ${{{{ env.ATHLETE_DIR }}}}/athlete_data.csv
        run: python generate_dashboard.py
        continue-on-error: true

      # ─── Save persec cache ─────────────────────────────────
      - name: Save persec cache
        uses: actions/cache/save@v4
        if: always()
        with:
          path: ${{{{ env.ATHLETE_DIR }}}}/persec_cache
          key: {slug}-persec-${{{{ github.run_number }}}}

      # ─── Upload results to Dropbox ──────────────────────────
      - name: Upload results to Dropbox
        if: always()
        run: |
          python ci/dropbox_sync.py upload \\
            --dropbox-base "${{{{ env.DB_BASE }}}}" \\
            --local-prefix "${{{{ env.ATHLETE_DIR }}}}" \\
            --items activity_overrides.xlsx \\
                    athlete.yml \\
                    athlete_data.csv \\
                    output/Master_{aid}_FULL.xlsx \\
                    output/Master_{aid}_FULL_post.xlsx \\
                    output/dashboard/index.html \\
                    output/_weather_cache_openmeteo/openmeteo_cache.sqlite \\
            --cache-dir ${{{{ env.ATHLETE_DIR }}}}/persec_cache"""
    
    # ── Pages deployment + summary ────────────────────────────
    pages_condition = gc if source == "intervals" else "success()"
    
    tail_block = f"""

      # ─── Deploy dashboard to GitHub Pages ──────────────────
      - name: Prepare dashboard for Pages
        {"if: " + gc if source == "intervals" else ""}
        run: |
          mkdir -p docs/{slug}
          cp -f ${{{{ env.ATHLETE_DIR }}}}/output/dashboard/index.html docs/{slug}/index.html 2>/dev/null || true
        continue-on-error: true

      - name: Deploy to GitHub Pages
        uses: peaceiris/actions-gh-pages@v3
        if: {pages_condition}
        with:
          github_token: ${{{{ secrets.GITHUB_TOKEN }}}}
          publish_dir: ./docs
          publish_branch: gh-pages
          keep_files: true
        continue-on-error: true

      # ─── Summary ────────────────────────────────────────────
      - name: Summary
        if: always()
        run: |
          echo "## {name} Pipeline Run Summary" >> $GITHUB_STEP_SUMMARY
          echo "" >> $GITHUB_STEP_SUMMARY
          echo "- **Trigger:** ${{{{ github.event_name }}}}" >> $GITHUB_STEP_SUMMARY
          echo "- **Mode:** ${{{{ github.event.inputs.mode || 'UPDATE' }}}}" >> $GITHUB_STEP_SUMMARY
          echo "- **Status:** ${{{{ job.status }}}}" >> $GITHUB_STEP_SUMMARY
          echo "- **Time:** $(date -u +%Y-%m-%dT%H:%M:%SZ)" >> $GITHUB_STEP_SUMMARY
          
          MASTER="${{{{ env.ATHLETE_DIR }}}}/output/Master_{aid}_FULL_post.xlsx"
          if [ -f "$MASTER" ]; then
            SIZE=$(stat -c%s "$MASTER" 2>/dev/null || echo "?")
            echo "- **Master size:** $SIZE bytes" >> $GITHUB_STEP_SUMMARY
          fi
          
          CACHE="${{{{ env.ATHLETE_DIR }}}}/persec_cache"
          if [ -d "$CACHE" ]; then
            COUNT=$(find "$CACHE" -name "*.npz" | wc -l)
            echo "- **NPZ cache:** $COUNT files" >> $GITHUB_STEP_SUMMARY
          fi"""
    
    # ── Assemble ──────────────────────────────────────────────
    workflow = f"""{header}

name: {name} Pipeline
{triggers}

concurrency:
  group: {slug}-pipeline
  cancel-in-progress: false

jobs:
  pipeline:
    runs-on: ubuntu-latest
    timeout-minutes: 600
{env_block}
{common_steps}
{sync_block}
{pipeline_block}
{tail_block}
"""
    return workflow


def generate_override_xlsx(path: str, races: list[dict] = None, race_times: list[dict] = None):
    """Generate activity_overrides.xlsx with detected races and PB time overrides."""
    if not HAS_OPENPYXL:
        print(f"  ⚠ openpyxl not installed — creating empty override placeholder")
        # Write a minimal file marker
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).touch()
        return
    
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "overrides"
    
    headers = [
        "file", "race_flag", "parkrun", "official_distance_km", "surface", "surface_adj",
        "temp_override", "power_override_w", "official_time_s", "notes"
    ]
    ws.append(headers)
    
    # Style header
    from openpyxl.styles import Font, PatternFill
    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_idx)
        cell.font = Font(bold=True)
        cell.fill = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
    
    # Add detected races (from FIT scanning)
    if races:
        for r in races:
            is_parkrun = r.get("race_type") == "parkrun"
            ws.append([
                r["file"],
                True,
                is_parkrun,
                r["distance_km"],
                None,  # surface
                None,  # surface_adj
                None,  # temp_override
                None,  # power_override_w
                None,  # official_time_s
                f"Auto-detected {r['race_type']} ({r['confidence']} confidence) — "
                f"{r['duration_min']:.1f}min, {r['pace_min_km']:.2f}/km, HR {r.get('avg_hr', '?')}"
            ])
    
    # Add PB / official time overrides (from onboarding form)
    if race_times:
        for rt in race_times:
            date_str = rt.get("date") or ""
            dist_km = rt.get("distance_km")
            time_s = rt.get("time_s")
            if not dist_km or not time_s:
                continue
            # Format time for human-readable note
            h = int(time_s // 3600)
            m = int((time_s % 3600) // 60)
            s = int(time_s % 60)
            time_fmt = f"{h}:{m:02d}:{s:02d}" if h > 0 else f"{m}:{s:02d}"
            # Use date as file identifier (StepB resolves to actual filename)
            file_col = date_str if date_str else f"[match {dist_km}km]"
            ws.append([
                file_col,
                1,      # race_flag
                0,      # parkrun
                dist_km,
                None,   # surface
                None,   # surface_adj
                None,   # temp_override
                None,   # power_override_w
                time_s, # official_time_s
                f"Onboarding: {time_fmt} for {dist_km}km" + (f" on {date_str}" if date_str else "")
            ])
    
    # Auto-width columns
    for col in ws.columns:
        max_len = max(len(str(cell.value or "")) for cell in col)
        ws.column_dimensions[col[0].column_letter].width = min(max_len + 3, 50)
    
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    wb.save(path)


def generate_athlete_data_csv(path: str):
    """Generate empty athlete_data.csv with correct headers."""
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("date,weight_kg,resting_hr,hrv,sleep_hours,notes\n")


# ═════════════════════════════════════════════════════════════════════════════
# INTERACTIVE MODE
# ═════════════════════════════════════════════════════════════════════════════

def interactive_config() -> dict:
    """Collect athlete info interactively."""
    print("\n╔══════════════════════════════════════════╗")
    print("║   Athlete Onboarding — Running Pipeline  ║")
    print("╚══════════════════════════════════════════╝\n")
    
    cfg = {}
    
    # Basic info
    cfg["name"] = input("  Athlete name: ").strip()
    if not cfg["name"]:
        print("  ✗ Name is required")
        sys.exit(1)
    
    cfg["dob"] = input("  Date of birth (YYYY-MM-DD): ").strip()
    cfg["gender"] = input("  Gender (male/female): ").strip().lower()
    
    mass_str = input("  Weight in kg: ").strip()
    cfg["mass_kg"] = float(mass_str) if mass_str else 70.0
    
    # HR — can be auto-estimated if FIT scan is used
    print("\n  HR thresholds (leave blank to auto-estimate from FIT files):")
    lthr_str = input("    LTHR (lactate threshold HR): ").strip()
    max_hr_str = input("    Max HR: ").strip()
    cfg["lthr"] = int(lthr_str) if lthr_str else None
    cfg["max_hr"] = int(max_hr_str) if max_hr_str else None
    
    # Timezone
    tz = input("\n  Timezone [Europe/London]: ").strip()
    cfg["timezone"] = tz if tz else "Europe/London"
    
    # Data source
    print("\n  Data source:")
    print("    1. FIT files in a folder/zip (simplest)")
    print("    2. intervals.icu (automated sync)")
    src = input("  Choice [1]: ").strip()
    cfg["data_source"] = "intervals" if src == "2" else "fit_folder"
    
    # FIT scan
    fit_path = input("\n  Path to FIT files (folder or .zip) for scanning [skip]: ").strip()
    cfg["fit_scan_path"] = fit_path if fit_path else None
    
    return cfg


# ═════════════════════════════════════════════════════════════════════════════
# MAIN
# ═════════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(description="Onboard a new athlete")
    parser.add_argument("--config", help="JSON config file (skip interactive)")
    parser.add_argument("--scan-fits", help="Path to FIT files to scan (folder or .zip)")
    parser.add_argument("--output-dir", default=".", help="Base directory for output")
    parser.add_argument("--dry-run", action="store_true", help="Print what would be created")
    args = parser.parse_args()
    
    # ── Gather config ─────────────────────────────────────────
    if args.config:
        with open(args.config, encoding="utf-8") as f:
            raw = f.read()
        
        # Strip trailing spaces from each line (email clients add them)
        raw = "\n".join(line.rstrip() for line in raw.splitlines())
        
        # Try parsing as pure JSON first
        try:
            cfg = json.loads(raw)
        except json.JSONDecodeError:
            # Not pure JSON — try extracting from email body
            # Support multiple marker styles
            marker_pairs = [
                ("--- CONFIG JSON START ---", "--- CONFIG JSON END ---"),
                ("CONFIG JSON", "{"),  # Old-style: header line, then JSON starts at {
            ]
            
            cfg = None
            for start_m, end_m in marker_pairs:
                if start_m in raw:
                    if end_m == "{":
                        # Old style: find the header, then extract from first { to last }
                        after_header = raw.split(start_m, 1)[1]
                        # Skip past the === line if present
                        brace_pos = after_header.find("{")
                        if brace_pos >= 0:
                            json_candidate = after_header[brace_pos:]
                            # Find matching closing brace by trying progressively
                            depth = 0
                            end_pos = 0
                            for i, ch in enumerate(json_candidate):
                                if ch == "{": depth += 1
                                elif ch == "}": depth -= 1
                                if depth == 0:
                                    end_pos = i + 1
                                    break
                            json_str = json_candidate[:end_pos]
                    else:
                        json_str = raw.split(start_m, 1)[1].split(end_m, 1)[0].strip()
                    
                    try:
                        cfg = json.loads(json_str)
                        print(f"  Extracted JSON config from email body")
                        break
                    except json.JSONDecodeError:
                        continue
            
            if cfg is None:
                print(f"ERROR: {args.config} is not valid JSON and no config block found.")
                print(f"  Paste the entire email body into the file, or just the JSON block.")
                sys.exit(1)
    else:
        cfg = interactive_config()
    
    # Override scan path from CLI
    if args.scan_fits:
        cfg["fit_scan_path"] = args.scan_fits
    
    # Derived names — use athlete ID for folder, slug (first name) for workflow/pages
    athlete_id = next_athlete_id(args.output_dir)
    cfg["athlete_id"] = athlete_id
    cfg["folder_name"] = athlete_id  # e.g. A005
    cfg["slug"] = make_slug(cfg["name"])  # e.g. ian (for workflow file, pages path, cache keys)
    
    base = Path(args.output_dir)
    athlete_dir = base / "athletes" / cfg["folder_name"]
    workflow_dir = base / ".github" / "workflows"
    
    # ── FIT scanning ──────────────────────────────────────────
    scan_results = None
    detected_races = []
    
    if cfg.get("fit_scan_path"):
        if not HAS_FITPARSE:
            print("\n⚠ fitparse not installed. Install with: pip install fitparse")
            print("  Skipping FIT scan — you'll need to set HR zones manually.\n")
        else:
            print(f"\n📁 Scanning FIT files...")
            runs = scan_fit_folder(cfg["fit_scan_path"])
            
            if runs:
                # Date range
                dates = [r["date"] for r in runs if r.get("date")]
                print(f"\n  📊 Summary:")
                print(f"     Runs: {len(runs)}")
                print(f"     Period: {min(dates)} → {max(dates)}")
                
                # HR estimation
                hr_info = estimate_hr_zones(runs)
                print(f"\n  ❤️  HR estimation:")
                print(f"     Max HR: {hr_info['max_hr']}")
                print(f"     LTHR: {hr_info['lthr']} ({hr_info['confidence']} confidence)")
                print(f"     {hr_info['note']}")
                
                if cfg.get("lthr") is None and hr_info["lthr"]:
                    cfg["lthr"] = hr_info["lthr"]
                if cfg.get("max_hr") is None and hr_info["max_hr"]:
                    cfg["max_hr"] = hr_info["max_hr"]
                
                # Power meter detection
                power_info = detect_power_meter(runs)
                print(f"\n  ⚡ Power: {power_info['note']}")
                
                n_power = power_info.get("n_power", 0)
                user_declared_stryd = cfg.get("power_mode") == "stryd"
                
                if user_declared_stryd:
                    if n_power >= 50:
                        # Plenty of Stryd data — honour the declaration
                        print(f"  ⚡ User declared Stryd, {n_power} runs with power → Stryd mode")
                        cfg["power_mode"] = "stryd"
                    elif n_power >= 10:
                        # Some Stryd data — honour, but note it'll improve
                        print(f"  ⚡ User declared Stryd, {n_power} runs with power → Stryd mode (will improve as data grows)")
                        cfg["power_mode"] = "stryd"
                    elif n_power > 0:
                        # Very few power runs — start in GAP, switch later
                        print(f"  ⚠ User declared Stryd but only {n_power} runs with power data")
                        print(f"  ⚠ Starting in GAP mode — switch to 'stryd' in athlete.yml when more power data accumulates")
                        cfg["power_mode"] = "gap"
                        cfg["_stryd_declared"] = True
                    else:
                        # No power data at all
                        print(f"  ⚠ User declared Stryd but no power data found in FIT files")
                        print(f"  ⚠ Starting in GAP mode — switch to 'stryd' in athlete.yml when power data appears")
                        cfg["power_mode"] = "gap"
                        cfg["_stryd_declared"] = True
                elif cfg.get("power_mode"):
                    print(f"  ⚡ User declared power_mode: {cfg['power_mode']} (keeping)")
                else:
                    cfg["power_mode"] = power_info["mode"]
                
                # Race detection
                detected_races = detect_races(runs)
                if detected_races:
                    high_conf = [r for r in detected_races if r["confidence"] == "high"]
                    med_conf = [r for r in detected_races if r["confidence"] == "medium"]
                    low_conf = [r for r in detected_races if r["confidence"] == "low"]
                    print(f"\n  🏁 Detected {len(detected_races)} potential races:")
                    print(f"     High confidence: {len(high_conf)}")
                    print(f"     Medium confidence: {len(med_conf)}")
                    print(f"     Low confidence: {len(low_conf)}")
                    
                    # Show top 10
                    for r in detected_races[:10]:
                        conf_icon = {"high": "✓", "medium": "~", "low": "?"}[r["confidence"]]
                        print(f"     {conf_icon} {r['date']}  {r['race_type']:>8}  "
                              f"{r['duration_min']:6.1f}min  {r['pace_min_km']:.2f}/km  "
                              f"HR {r.get('avg_hr', '?')}")
                    if len(detected_races) > 10:
                        print(f"     ... and {len(detected_races) - 10} more")
                
                scan_results = {
                    "n_runs": len(runs),
                    "date_range": (min(dates), max(dates)),
                    "hr_info": hr_info,
                    "power_info": power_info,
                    "n_races": len(detected_races),
                }
    
    # ── Defaults for missing values ───────────────────────────
    if cfg.get("lthr") is None:
        cfg["lthr"] = 160  # generic default
        print("  ⚠ Using default LTHR=160. Update in athlete.yml once known.")
    if cfg.get("max_hr") is None:
        cfg["max_hr"] = 185  # generic default
        print("  ⚠ Using default max_hr=185. Update in athlete.yml once known.")
    if cfg.get("power_mode") is None:
        cfg["power_mode"] = "gap"
    
    # ── Generate files ────────────────────────────────────────
    print(f"\n{'═' * 60}")
    print(f"  Generating files for {cfg['name']}")
    print(f"{'═' * 60}\n")
    
    files_to_create = {
        str(athlete_dir / "athlete.yml"): generate_athlete_yml(cfg),
        str(workflow_dir / f"{cfg['slug']}_pipeline.yml"): generate_workflow_yml(cfg),
    }
    
    if args.dry_run:
        for path, content in files_to_create.items():
            print(f"  Would create: {path}")
            print(f"    ({len(content)} chars)")
        print(f"  Would create: {athlete_dir}/activity_overrides.xlsx")
        print(f"    ({len(detected_races)} races pre-populated)")
        print(f"  Would create: {athlete_dir}/athlete_data.csv")
        return
    
    # Create directories
    athlete_dir.mkdir(parents=True, exist_ok=True)
    (athlete_dir / "data").mkdir(exist_ok=True)
    (athlete_dir / "persec_cache").mkdir(exist_ok=True)
    (athlete_dir / "output" / "dashboard").mkdir(parents=True, exist_ok=True)
    workflow_dir.mkdir(parents=True, exist_ok=True)
    
    # Write text files
    for path, content in files_to_create.items():
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"  ✓ {path}")
    
    # Write override xlsx
    override_path = str(athlete_dir / "activity_overrides.xlsx")
    race_times = cfg.get("race_times", [])
    generate_override_xlsx(override_path, detected_races, race_times)
    print(f"  ✓ {override_path}")
    if detected_races:
        print(f"    → {len(detected_races)} races pre-populated (review & edit before running)")
    if race_times:
        print(f"    → {len(race_times)} official time override(s) from onboarding form")
    
    # Write athlete_data.csv
    data_path = str(athlete_dir / "athlete_data.csv")
    generate_athlete_data_csv(data_path)
    print(f"  ✓ {data_path}")
    
    # ── Post-creation instructions ────────────────────────────
    slug = cfg["slug"]
    folder = cfg["folder_name"]
    secret_prefix = slug.upper()
    source = cfg.get("data_source", "fit_folder")
    has_intervals = source == "intervals"
    has_strava = source == "strava_export"
    
    print(f"\n{'─' * 60}")
    print(f"  NEXT STEPS")
    print(f"{'─' * 60}\n")
    
    step = 1
    
    # Dropbox upload
    print(f"  {step}. COPY to Dropbox:")
    print(f"     /Running and Cycling/DataPipeline/athletes/{folder}/")
    print(f"       Copy these files from {athlete_dir}/:")
    print(f"         athlete.yml")
    print(f"         activity_overrides.xlsx")
    print(f"         athlete_data.csv")
    if has_strava:
        print(f"       Then copy the athlete's Strava export as:")
        print(f"         data/strava_export.zip")
    elif has_intervals:
        print(f"       Athlete data: upload their export (if any) as one of:")
        print(f"         data/strava_export.zip  OR  data/garmin_export.zip  OR  data/fits.zip")
        print(f"       (Or skip — INITIAL will try intervals.icu if no file found)")
    else:
        print(f"       Then copy the athlete's data export as one of:")
        print(f"         data/strava_export.zip  OR  data/garmin_export.zip  OR  data/fits.zip")
    step += 1
    
    # GitHub secrets
    if has_intervals:
        int_id = cfg.get("intervals_id", "")
        int_key = cfg.get("intervals_key", "")
        print(f"\n  {step}. GITHUB SECRETS — add to repository:")
        print(f"     {secret_prefix}_INTERVALS_API_KEY    = {int_key or '<from athlete email>'}")
        print(f"     {secret_prefix}_INTERVALS_ATHLETE_ID = {int_id or '<from athlete email>'}")
        step += 1
    
    # Push
    print(f"\n  {step}. PUSH to GitHub:")
    print(f"     git add athletes/{folder}/ .github/workflows/{slug}_pipeline.yml")
    print(f"     git commit -m \"Add {cfg['name']}\"")
    print(f"     git push")
    step += 1
    
    # Trigger
    first_mode = "INITIAL"
    print(f"\n  {step}. TRIGGER first run:")
    print(f"     GitHub Actions → {cfg['name']} Pipeline → Run workflow → mode: {first_mode}")
    step += 1
    
    print(f"\n  Dashboard will appear at:")
    print(f"     https://dobssi.github.io/Fitness-Data/{slug}/")
    
    if race_times:
        print(f"\n  ℹ️  {len(race_times)} official time correction(s) loaded into activity_overrides.xlsx")
        print(f"     These will be applied when StepB runs (matched by date + distance)")
    
    if detected_races:
        print(f"\n  ℹ️  {len(detected_races)} auto-detected races in activity_overrides.xlsx")
        print(f"     Review {override_path} before running")
    
    # Save config for reference
    config_path = str(athlete_dir / "onboard_config.json")
    with open(config_path, "w", encoding="utf-8") as f:
        save_cfg = {k: v for k, v in cfg.items() if k != "fit_scan_path"}
        if scan_results:
            save_cfg["scan_results"] = {
                "n_runs": scan_results["n_runs"],
                "date_range": scan_results["date_range"],
                "n_races": scan_results["n_races"],
            }
        json.dump(save_cfg, f, indent=2, default=str)
    print(f"\n  💾 Config saved: {config_path}")
    
    print(f"\n{'═' * 60}")
    print(f"  Done! Copy to Dropbox, push, trigger {first_mode}.")
    print(f"{'═' * 60}\n")


if __name__ == "__main__":
    main()
