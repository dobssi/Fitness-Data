# Handover: Alert 5 Retirement, Specificity Fix, Cold Temperature Adjustment
## Date: 2026-02-16

---

## Changes Made This Session

### 1. Alert 5 Retired (StepB_PostProcess.py, generate_dashboard.py)

Alert 5 (Easy RF divergence) removed from the pipeline. Analysis showed:
- **2023 DNF validation case**: Alert 5 was silent (gap never below -0.7%). Alert 2 caught the overreaching.
- **2018 peak fitness**: Alert 5 fired at -3.8% during best performances — false positive caused by Power Score boosts inflating RFL_Trend while Easy RF EMA can't follow.
- **Jan 2026**: Fired on recovering trajectory before strong indoor 3000m race. Not actionable.

**Root cause**: Alert 5 measures how much better you race than you jog, not fatigue. Power Score boosts widen the gap mechanically at peak fitness.

**What was removed**:
- Bit 4 (16) from alert bitmask — now 4 alerts, bitmask 0-15
- `ALERT5_GAP_THRESHOLD` config constant
- `Alert_5` legacy bool column
- Alert 5 block in `get_current_alerts()`
- Alert 5 definition in dashboard `get_alert_data()`
- `ez_gap` and `ez_ema` arrays from alert loop (Easy_RFL_Gap and Easy_RF_EMA columns still compute, just don't trigger alerts)

**Remaining alerts**: Alert 1 (CTL↑/RFL↓), Alert 1b (taper not working), Alert 2 (deep fatigue), Alert 3b (easy run outlier)

### 2. Race Readiness Specificity: "At or Above" Logic (generate_dashboard.py)

5K race cards now count Sub-5K + 5K zone minutes for specificity. All other distances count their own zone only.

```javascript
const SPEC_ZONES = {
  'Sub-5K': ['Sub-5K'],
  '5K': ['Sub-5K', '5K'],
  '10K': ['10K'],
  'HM': ['HM'],
  'Mara': ['Mara']
};
```

**Why**: 5K interval sessions (342W avg) sit right on the 10K/5K zone boundary (342W). Sub-5K seconds from the same intervals were being discarded. For ≤5K distances, faster-than-target effort is clearly race-specific preparation. For longer distances (HM, marathon), faster effort is a different energy system and shouldn't count.

**Analysis of two identical 5×3' @ 5K effort sessions (Feb 12 & 16)**:
- Power mode: 14min at 5K effort (Sub-5K excluded)
- GAP mode: 22min at 5K effort (tighter pace distribution)
- GAP correctly classifies more time as 5K-specific because GAP pace clusters tighter than power in the 5K zone

### 3. Cold Temperature Adjustment (StepB_PostProcess.py)

Added U-shaped temperature model. Previously only heat above base_temp was penalised; now cold below 5°C also gets an adjustment.

**New constants**:
```python
'temp_cold_threshold': 5,      # °C below which cold penalty applies
'temp_cold_factor': 0.0015,    # Penalty per °C below threshold
```

**Temperature curve**:
| Temp | Adjustment | Notes |
|------|-----------|-------|
| -15°C | +3.0% | Extreme Stockholm winter |
| -10°C | +2.2% | |
| -5°C | +1.5% | |
| 0°C | +0.8% | |
| 5-16°C | 0% | Neutral zone |
| 20°C | +1.2% | Mild heat |
| 25°C | +6.7% | Heat + humidity |
| 30°C | +15.5% | Extreme heat |

**Research basis**: Ioannou et al. 2021 (1,258 races): optimal 7.5-15°C WBGT, 0.3-0.4% per degree outside. Ely et al. 2007: U-shaped curve, asymmetric (cold much less severe than heat). Cold factor set at ~half the mild heat rate.

**Cold is NOT duration-scaled** (unlike heat):
- Heat compounds over time (thermoregulatory cascade) → scaled by duration/90min
- Cold effects are immediate (vasoconstriction, muscle stiffness, air density) → flat adjustment
- This applies in BOTH the RF pathway (temp_adj_for_rf) and Power Score pathway (ps_temp_adj)

**Bug found and fixed**: Initial deployment had cold penalty being duration-scaled through `rf_heat_multiplier` (≈0.22 for RF window), reducing -16°C adjustment from 3.15% to 0.7%. Fixed by separating cold and heat components before applying duration scaling.

**Impact**: 704 runs (23% of dataset) below 5°C now get cold credit. Mean adjustment +0.73%. Will systematically lift winter RF values, reducing seasonal fitness dip that was partly temperature-induced.

### 4. Easy Run Classification Refinement (StepB_PostProcess.py)

Changed easy run mask to use OR logic with dual gates:
- Easy if **HR ≤ 148** OR **nPower < RF_THR × 148**
- Plus: distance ≥ 4km, VI < 1.10, not a race

This correctly excludes structured sessions like F4 (HR 152, nP 284W) while including easy+strides runs. The HR ceiling of 148 = lower half of Z2 (Aerobic zone boundary 140-155).

### 5. RF×HR Anchored Training Zones (generate_dashboard.py)

Zone boundaries now derived from `power = (CP/LTHR) × HR_boundary`:
- Z1 Easy: <140 HR, <262W
- Z2 Aerobic: 140-155 HR, 262-290W  
- Z3 Tempo: 155-169 HR, 290-316W
- Z4 Threshold: 169-178 HR, 316-333W
- Z5 Max: >178 HR, >333W

Old Z2/Z3 split was at 160 HR; new split at 155 (tempo threshold). Power zones shift automatically with fitness via RF ratio.

---

## Files Modified

- **StepB_PostProcess.py**: Alert 5 removal, cold temp adjustment, easy run mask refinement
- **generate_dashboard.py**: Alert 5 removal, specificity "at or above" logic, RF×HR zone anchoring

---

## Key Decisions / Learnings

1. **Stryd pod weight = 76kg** (ATHLETE_MASS_KG in config). Dashboard 7d weight average is different. RE = power/(speed×mass) must use 76kg. Added to memory.

2. **GAP mode is sound for specificity**: GAP adjusts per-second pace for grade. RE_p90 bakes in real-world conditions. Wind is the one thing GAP can't correct — accepted limitation.

3. **Race power zone boundaries are structurally narrow**: 5K zone floor (342W) = midpoint of CP and CP×1.05. Widening zones would break stacked charts. Solution: "at or above" counting for ≤5K specificity instead.

4. **Cold penalty mechanism differs from heat**: Heat compounds (thermoregulation fails over time). Cold is immediate (vasoconstriction, stiffness). Therefore cold adjustment must NOT be duration-scaled.

---

## For Next Claude

"v51 session: Alert 5 retired (false positives at peak fitness, missed 2023 DNF). Specificity now counts Sub-5K+5K for 5K races. Cold temperature adjustment added (0.15%/°C below 5°C, NOT duration-scaled — bug was found where RF heat multiplier was scaling cold down to 22%). Easy run mask uses HR≤148 OR nPower<mid-Z2. Training zones anchored via RF×HR. All changes in StepB_PostProcess.py and generate_dashboard.py."
